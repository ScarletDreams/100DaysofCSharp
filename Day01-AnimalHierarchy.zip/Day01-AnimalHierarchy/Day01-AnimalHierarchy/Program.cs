﻿namespace Day01_AnimalHierarchy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Cat cat = new Cat { Name = "Luna" };
            Dog dog = new Dog { Name = "Zoe" };

            // A messier way to do the same thing. 
            // I think the code above feels cleaner. 

            // Cat cat = new Cat();
            // cat.Name = "Luna";

            // Dog dog = new Dog();
            // dog.Name = "Zoe";

            cat.Eat();
            cat.Meow();
            

            dog.Eat();
            dog.Bark();
        }
    }

    // This is the base class or the 'mother' from which other classes are derived or 'born' from it. 
    // Specified accessability as public so it could be reached after getting (Compiler Error: CS0060).
    public class Animal
    {
        public string Name { get; set; }

        public void Eat()
        {
            Console.WriteLine($"{Name} is eating.");
        }
    }

    // The derived class or the 'child' that looks up to the 'mother'.
    // Dog is derived from Animal
    public class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine($"{Name} says woof! \n");
        }
    }

    public class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine($"{Name} says meow. \n");
        }
    }

}
