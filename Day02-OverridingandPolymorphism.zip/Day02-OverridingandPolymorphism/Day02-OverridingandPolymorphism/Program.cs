﻿namespace Day02_OverridingandPolymorphism
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // A list  containing our animals. 
            List<Animal> animals = new List<Animal>()
           {
               new Dog {Name = "Zoe"},
               new Cat {Name = "Luna"},
               new Bird {Name = "Dancer"}
           };

            // If animal also implements movement 
            // call its Move() method via IMoving
            foreach (Animal a in animals)
            {
                a.Eat();
                a.Talk();

                if (a is IMoving m)
                {
                    m.Move();
                }
            }


        }
    }

    // This base class defines core identity and behavior of all animals.
    public abstract class Animal
    {
        public string Name { get; set; }
        public abstract void Talk();
        public virtual void Eat()
        {
            Console.WriteLine($"{Name} is eating");
        }

    }

    // Interface: Defines a contract for movement behavior.
    public interface IMoving
    {
        void Move();
    }

    // All the animals are listed below and inherit from the Animal class. 
    // Each of them must use Move() and override Eat() and Talk()
    public class Dog : Animal, IMoving
    {
        public override void Talk()
        {
            Console.WriteLine($"{Name} says woof!");
        }

        public override void Eat()
        {
            Console.WriteLine($"{Name} scarfs down the dog food.");
        }

        public void Move()
        {
            Console.WriteLine($"{Name} has the zoomies.\n");
        }
    }

    public class Cat : Animal, IMoving
    {
        public override void Talk()
        {
            Console.WriteLine($"{Name} says meow.");
        }

        public override void Eat()
        {
            Console.WriteLine($"{Name} nibbles on some tuna.");
        }

        public void Move()
        {
            Console.WriteLine($"{Name} is climbing the curtains.\n");
        }
    }

    public class Bird : Animal, IMoving
    {
        public override void Talk()
        {
            Console.WriteLine($"{Name} says coo coo.");
        }

        public override void Eat()
        {
            Console.WriteLine($"{Name} pecks at breadcrumbs.");
        }

        public void Move()
        {
            Console.WriteLine($"{Name} got spooked and flew away.\n");
        }
    }

}
