﻿namespace Day04_EncapsulationandProperties
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Item> Inventory = new List<Item>()
            {
                 new Item("1001", "Magic Scroll", 12, 10),
                 new Item("1002", "Health Potion", 20, 5),
                 new Item("1003", "Iron Sword", 5, 50)
            };

            Console.WriteLine("Welcome! Here is what we currently have in stock:");
            foreach (var item in Inventory)
            {
                Console.WriteLine($"{item.Id} - {item.Name} ({item.Quantity} in stock) - {item.Price} gold each");
            }

            Console.WriteLine("So, what can I get for you? Gimme the name or item number.");
            string choice = Console.ReadLine();


            if (int.TryParse(choice, out int id))
            {
                // If user types a number, look up by id.
                Item selected = Inventory.FirstOrDefault(i => i.Id == id.ToString());

                if (selected != null)
                {
                    Console.WriteLine($"You selected {selected.Name}");
                }
                else
                {
                    Console.WriteLine("No item found with that ID.");
                }
            }
            else
            {
                // If the user types a name, look up by name.
                Item selected = Inventory.FirstOrDefault(i => i.Name.Equals(choice, StringComparison.OrdinalIgnoreCase));

                if (selected != null)
                {
                    Console.WriteLine($"You selected {selected.Name}");
                }
                else
                {
                    Console.WriteLine("No item found with that name.");
                }

            }

        }
        internal class Item
        {
            public string Id { get; }
            public string Name { get; }
            public int Quantity { get; private set; }
            public int Price { get; }  
            public int TotalValue => Quantity * Price;

            public Item(string id, string name, int quantity, int price)
            {
                if (quantity < 0) throw new ArgumentOutOfRangeException(nameof(quantity));

                Id = id;
                Name = name;
                Quantity = quantity;
                Price = price;
            }

            public int Purchase(int amount)
            {
                if (amount <= 0) return 0;

                int bought = Math.Min(amount, Quantity);
                Quantity -= bought;
                return bought;
            }


        }

    }

}
