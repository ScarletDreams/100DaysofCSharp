﻿
namespace Day03_AbstractClassesAndInterfaces
{
    internal class Program
    {
        static void Main(string[] args)
        {

            List<Character> characters = new List<Character>()
            {
                new MyCharacter {Name = "Sam"},
                new NPC {Name = "Shopkeeper Charlie"}
            };

            foreach (Character x in characters)
            {
                x.Walk();
                x.Run();

                if (x is IHungry m) { x.Eat(); x.Sleep(); }
            }

            List<Pet> pets = new List<Pet>()
            {
                new Pet {Name = "Babadook"}
            };

            foreach (Pet x in pets)
            {
                if (x is IHungry m) { x.Eat(); x.Sleep(); }
            }

        }

        public interface IHungry
        {
            void Eat();
        }

        public interface ISleepy
        {
            void Sleep();
        }

        public abstract class Character : IHungry, ISleepy
        {
            public string Name { get; set; }
            public abstract void Walk();
            public abstract void Run();

            public void Eat()
            {
                Console.WriteLine($"{Name} is eating something delicious.");
            }

            public void Sleep()
            {
                Console.WriteLine($"{Name} was tired and went to sleep.\n");
            }
        }

        public class MyCharacter : Character
        {
            public override void Walk()
            {
                Console.WriteLine($"{Name} is walking.");
            }


            public override void Run()
            {
                Console.WriteLine($"{Name} is running.");
            }
        }


        public class NPC : Character
        {
            public override void Walk()
            {
                Console.WriteLine($"{Name} is walking.");
            }


            public override void Run()
            {
                Console.WriteLine($"{Name} is running.");
            }
        }

        public class Pet : IHungry, ISleepy
        {
            public string Name { get; set; }

            public void Eat()
            {
                Console.WriteLine($"{Name} was hungry and ate something.");
            }

            public void Sleep()
            {
                Console.WriteLine($"{Name} was tired and slept.\n");
            }
        }

    }

}
